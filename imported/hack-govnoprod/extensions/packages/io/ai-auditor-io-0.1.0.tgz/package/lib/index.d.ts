export declare function makeTempDir(prefix?: string): Promise<string>;
export declare function sha256File(path: string): Promise<string>;
export declare function toNdjsonGz(filePaths: string[], outPath: string, stripKeys?: string[], logger?: (m: string) => void): Promise<number>;
export declare function zipFiles(outZip: string, entries: Array<{
    name: string;
    path: string;
}>): Promise<void>;
export declare function globMany(globs: string[], cwd: string): Promise<string[]>;
export declare function httpUpload(url: string, zipPath: string, token?: string, headers?: Record<string, string>, opts?: {
    retry?: number;
    chunked?: boolean;
    partSize?: number;
}): Promise<{
    status: any;
    body: any;
}>;
export declare function httpGet(url: string, token?: string, headers?: Record<string, string>, opts?: {
    timeoutMs?: number;
    retry?: number;
}): Promise<{
    status: any;
    body: any;
    json: () => Promise<any>;
} | {
    status: number;
    body: string;
    json?: undefined;
}>;
